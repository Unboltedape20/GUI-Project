package datahandler;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package gui_tutorial;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
//import org.jfree.data.category.DefaultCategoryDataset;

public class DataHandler {
// DB details

    private static final String dbURL = "jdbc:ucanaccess://hotel_1.accdb;sysSchema=true";
    private static java.sql.Connection con;
    private static java.sql.Statement stm;
    private static java.sql.ResultSet rs;
    private static java.sql.ResultSetMetaData rsMeta;
    private static int columnCount;
    private static java.sql.PreparedStatement pstm;

    public static Vector<String> getTables() {
        Vector<String> l = new Vector<>();
        /*l.add("Employee");
        l.add("Dependant");
        l.add("Department");
        l.add("Project");
        l.add("Workson");*/
        String sqlQuery = "SELECT Name FROM sys.MSysObjects WHERE Type=1 AND Flags=0";
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            stm = con.createStatement();
            rs = stm.executeQuery(sqlQuery);
            while (rs.next()) {
                // each row is an array of objects
                l.add((String) rs.getObject(1));
            }
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        } finally {
            try {
                if (null != con) {
                    // cleanup resources, once after processing
                    rs.close();
                    stm.close();
                    // and then finally close connection
                    con.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(DataHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return l;
    }

    public static void searchRecords(String table) {
        String sqlQuery = "SELECT * FROM " + table;
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            stm = con.createStatement(
                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                    java.sql.ResultSet.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sqlQuery);
            rsMeta = rs.getMetaData();
            columnCount = rsMeta.getColumnCount();
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }

    public static Object[] getTitles(String table) {
        Object[] columnNames = new Object[columnCount];
        try {
            for (int col = columnCount; col > 0; col--) {
                columnNames[col - 1]
                        = rsMeta.getColumnName(col);
            }
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } finally {
            try {
                if (null != con) {
                    // cleanup resources, once after processing
                    rs.close();
                    stm.close();
                    // and then finally close connection
                    con.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(DataHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return columnNames;
    }

    public static Object[][] getRows(String table) {
        searchRecords(table);
        Object[][] content;
        try {
// determine the number of rows
            rs.last();
            int number = rs.getRow();
            content = new Object[number][columnCount];
            rs.beforeFirst();
            int i = 0;
            while (rs.next()) {
// each row is an array of objects
                for (int col = 1; col <= columnCount; col++) {
                    content[i][col - 1] = rs.getObject(col);
                }
                i++;
            }
            return content;
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        }
        return null;
    }

    public static void addGuestRecords( String GuestName, String GuestPassword, String GuestContact, String GuestRoomNum) {
        String sqlQuery = "INSERT INTO Guest (username,password,contact_info,room_num) VALUES (?,?,?,?)";
        System.out.println(sqlQuery);
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, GuestName);
            pstm.setObject(2, GuestPassword);
            pstm.setObject(3, GuestContact);
            pstm.setObject(4, GuestRoomNum);

            int p = pstm.executeUpdate();
//            stm = con.createStatement(
//                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    java.sql.ResultSet.CONCUR_READ_ONLY);
//            rs = stm.executeQuery(sqlQuery);
//            rsMeta = rs.getMetaData();
//            columnCount = rsMeta.getColumnCount();
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }

    public static void updateGuestRecords(String GuestID,String GuestName, String GuestContact, String GuestRoomNum) {
        String sqlQuery = "UPDATE Guest SET username = ?, contact_info = ?, room_num = ? WHERE guest_id = ?;";
        System.out.println(sqlQuery);
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, GuestName);
            pstm.setObject(2, GuestContact);
            pstm.setObject(3, GuestRoomNum);
            pstm.setObject(4, GuestID);
//            pstm.setObject(5, BabyID);

            int p = pstm.executeUpdate();
//            stm = con.createStatement(
//                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    java.sql.ResultSet.CONCUR_READ_ONLY);
//            rs = stm.executeQuery(sqlQuery);
//            rsMeta = rs.getMetaData();
//            columnCount = rsMeta.getColumnCount();
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }

    public static void deleteGuestRecords(String GuestID) {
        String sqlQuery = "Delete FROM Guest WHERE Guest_id = ?;";

        System.out.println(sqlQuery);
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);

            pstm.setObject(1, GuestID);

            int p = pstm.executeUpdate();
//            stm = con.createStatement(
//                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    java.sql.ResultSet.CONCUR_READ_ONLY);
//            rs = stm.executeQuery(sqlQuery);
//            rsMeta = rs.getMetaData();
//            columnCount = rsMeta.getColumnCount();
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }

    public static void addSleepRecords(String BabyID, String SleepBegin, String SleepFinish, String SleepLength, String SleepNotes) {
        String sqlQuery = "INSERT INTO SleepLog (BabyID,SleepStart,SleepEnd,Duration,Notes) VALUES (?,?,?,?,?)";
        System.out.println(sqlQuery);
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, BabyID);
            pstm.setObject(2, SleepBegin);
            pstm.setObject(3, SleepFinish);
            pstm.setObject(4, SleepLength);
            pstm.setObject(5, SleepNotes);

            int p = pstm.executeUpdate();
//            stm = con.createStatement(
//                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    java.sql.ResultSet.CONCUR_READ_ONLY);
//            rs = stm.executeQuery(sqlQuery);
//            rsMeta = rs.getMetaData();
//            columnCount = rsMeta.getColumnCount();
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }

    public static void addTempRecords(String BabyID, String TempReadTime, String TempReadValues, String TempNotes) {
        String sqlQuery = "INSERT INTO TemperatureReading (BabyID,ReadingDateTime,Temperature,Notes) VALUES (?,?,?,?)";
        System.out.println(sqlQuery);
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, BabyID);
            pstm.setObject(2, TempReadTime);
            pstm.setObject(3, TempReadValues);
            pstm.setObject(4, TempNotes);

            int p = pstm.executeUpdate();
//            stm = con.createStatement(
//                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    java.sql.ResultSet.CONCUR_READ_ONLY);
//            rs = stm.executeQuery(sqlQuery);
//            rsMeta = rs.getMetaData();
//            columnCount = rsMeta.getColumnCount();
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }

//    public static DefaultCategoryDataset linechartRecords() {
//        DefaultCategoryDataset dataset = new DefaultCategoryDataset();  
//        
//  
//        String sqlQuery = "SELECT Temperature,ReadingDateTime FROM TemperatureReading";
//        try {
//            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
//            con = DriverManager.getConnection(dbURL, "", "");
//            stm = con.createStatement(
//                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    java.sql.ResultSet.CONCUR_READ_ONLY);
//            rs = stm.executeQuery(sqlQuery);
//            rsMeta = rs.getMetaData();
//            columnCount = rsMeta.getColumnCount();
//
//            while(rs.next())
//            {
//                dataset.addValue(rs.getDouble(1), "hi" , rs.getString(2));  
//            }
//                
//        } catch (ClassNotFoundException cnfex) {
//            System.err.println("Issue with the JDBC driver.");
//            System.exit(1); // terminate program - cannot recover
//        } catch (java.sql.SQLException sqlex) {
//            System.err.println(sqlex);
//        } catch (Exception ex) {
//            System.err.println(ex);
//            //ex.printStackTrace();
//        }
//        
//        return dataset;
//    }
    public static int userlogin(String username, String password) {
        String sqlQuery = "SELECT guest_id FROM Guest WHERE username = ? and password = ?";
        System.out.println(sqlQuery);
        int id = -1;
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, username);
            pstm.setObject(2, password);

            // result set
            rs = pstm.executeQuery();
            while(rs.next())
            {
                id = rs.getInt(1);
            }

        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
        
        return id;
    }
    
    
    
    
    public static int userSignup(String username, String password) {
        String sqlQuery = "INSERT INTO Guest(username,password) VALUES (?,?)";
        System.out.println(username);
        int uid = 0;

        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, username);
            pstm.setObject(2, password);

            // result set
            pstm.executeUpdate();
            
            rs = pstm.getGeneratedKeys();
            while(rs.next()){
                uid = rs.getInt(1);
            }
            
            System.out.println("370");

        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
        return uid;
        
    }
    
     public static void updateguestRecords(String guest_username, String guest_password, String guest_id , String guest_contact) {
        String sqlQuery = "UPDATE Guest SET username = ?, password = ?,  contact_info= ? WHERE guest_id = ?;";
        System.out.println(sqlQuery);
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, guest_username);
            pstm.setObject(2, guest_password);
            pstm.setObject(3, guest_contact);
            pstm.setObject(4, guest_id);
            //System.out.println(guest_id);
       

            int p = pstm.executeUpdate();
//            stm = con.createStatement(
//                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    java.sql.ResultSet.CONCUR_READ_ONLY);
//            rs = stm.executeQuery(sqlQuery);
//            rsMeta = rs.getMetaData();
//            columnCount = rsMeta.getColumnCount();
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }
     
    public static void checkAvailableRooms() {
        String sqlQuery = "SELECT  room_id, room_number, type, is_available,availabe_start, availabe_finish, price FROM Room where is_available=" + 1;
        System.out.println("387");
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            stm = con.createStatement(
                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                    java.sql.ResultSet.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sqlQuery);
            rsMeta = rs.getMetaData();
            columnCount = rsMeta.getColumnCount();
            while(rs.next()){
                System.out.println(rs.getString(1));
            }
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }
    //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    public static Object[][] getRowsFromRoom() {
        checkAvailableRooms();
//        System.out.println("409");
        Object[][] content;
        try {
// determine the number of rows
            rs.last();
            int number = rs.getRow();
            content = new Object[number][columnCount];
            rs.beforeFirst();
            int i = 0;
            while (rs.next()) {
// each row is an array of objects
                for (int col = 1; col <= columnCount; col++) {
                    content[i][col - 1] = rs.getObject(col);
                }
                i++;
            }
            return content;
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        }
        return null;
    }
    
    // book room
    public static void updateguestroom(int userid, int roomnum) {
        String sqlQuery = "UPDATE Guest SET room_num = ? WHERE guest_id = ?";
        System.out.println(sqlQuery);
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, roomnum);
            pstm.setObject(2, userid);

            int p = pstm.executeUpdate();
//            stm = con.createStatement(
//                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    java.sql.ResultSet.CONCUR_READ_ONLY);
//            rs = stm.executeQuery(sqlQuery);
//            rsMeta = rs.getMetaData();
//            columnCount = rsMeta.getColumnCount();
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }
    
    
    
    public static void updateroomavail(int roomnum, int available) {
        String sqlQuery = "UPDATE room SET is_available = ? WHERE room_number = ?";
        System.out.println(sqlQuery);
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, available);
            pstm.setObject(2, roomnum);

            int p = pstm.executeUpdate();
//            stm = con.createStatement(
//                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    java.sql.ResultSet.CONCUR_READ_ONLY);
//            rs = stm.executeQuery(sqlQuery);
//            rsMeta = rs.getMetaData();
//            columnCount = rsMeta.getColumnCount();
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }
    
    public static int Stafflogin(String username, String password) {
        String sqlQuery = "SELECT staff_id FROM Staff WHERE username = ? and password = ?";
        System.out.println(sqlQuery);
        int id = -1;
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, username);
            pstm.setObject(2, password);

            // result set
            rs = pstm.executeQuery();
            while(rs.next())
            {
                id = rs.getInt(1);
            }

        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
        
        return id;
    }
    
    
    
     public static void loyaltypoints(String guest_id, int point) {
         System.out.println(point+"``"+guest_id);
        String sqlQuery = "SELECT points FROM LoyaltyProgram WHERE guest_id = ?";
        System.out.println(sqlQuery);
        //String sqlQuery = "UPDATE LoyaltyProgram SET guest_id = ?, points = ?,  WHERE guest_id = ?;";
        
        boolean check_points = false;
        int old_point = 0;
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, guest_id);
       
            rs = pstm.executeQuery();

            while(rs.next()){
                check_points = true;
                old_point = rs.getInt(1); 
            }
            
            if(check_points){
                point = point + old_point;
                sqlQuery = "UPDATE LoyaltyProgram SET points = ? WHERE guest_id = ?";
                System.out.println(sqlQuery);
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
                pstm.setObject(1, point);
                pstm.setObject(2, guest_id);
                pstm.executeUpdate();
            }else{
                //INSERT INTO Baby (Name, DateOfBirth,Gender,ParentName) VALUES (?,?,?,?)";
                sqlQuery = "INSERT INTO LoyaltyProgram (guest_id, points) VALUES (?,?)";
                System.out.println(sqlQuery);
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
                pstm.setObject(1, guest_id);
                System.out.println("point="+point);
                pstm.setObject(2, point);

                System.out.println(point);
                pstm.executeUpdate();
            }

        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }
    
     public static void checkOut(int guestid) {
        String sqlQuery = "UPDATE Guest SET room_num = ? WHERE guest_id = ?";
        System.out.println(sqlQuery);
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, 0);
            pstm.setObject(2, guestid);

            int p = pstm.executeUpdate();
//            stm = con.createStatement(
//                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    java.sql.ResultSet.CONCUR_READ_ONLY);
//            rs = stm.executeQuery(sqlQuery);
//            rsMeta = rs.getMetaData();
//            columnCount = rsMeta.getColumnCount();
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }
     
     
    public static int queryRoomnumber(int guestid) {
        String sqlQuery = "SELECT room_num FROM Guest WHERE guest_id = ?";
        System.out.println(sqlQuery);
        int num = -1;
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, guestid);


            // result set
            rs = pstm.executeQuery();
            while(rs.next())
            {
                num = rs.getInt(1);
            }

        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
        
        return num;
    }
    
    

}
